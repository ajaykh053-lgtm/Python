# rub the project you built
print(1)
print("Welcome to Band Name Generator")
city = input("what's the name of the city you gerw up in ?")
pet_name = input("what's your pet's name ?")  # variable

print(f"your band name could be : {city} {pet_name}")  # fstream

print("your band name could be : " + city + " " + pet_name)

# variable string input fstring etc
