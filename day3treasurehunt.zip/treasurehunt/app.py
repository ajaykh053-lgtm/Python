from flask import Flask,render_template_string
import subprocess
app=Flask(__name__)
@app.route('/')
def show_output():
    # running treasure hunt file and capturing the output
    result=subprocess.run(['python','treasurehunt.py'],capture_output=True,text=True)
    output=result.stdout
    # rendering the output to the html
    html=f"""<!DOCTYPE html>
    <html>
    <head><title>Treasure Hunt Output</title></head>
    <body>
        <h1>Output of treasurehunt.py</h1>
        <pre>{output}</pre>
    </body>
    </html>
    """
    return render_template_string(html)
if __name__=='__main__':
    app.run(debug=True)
