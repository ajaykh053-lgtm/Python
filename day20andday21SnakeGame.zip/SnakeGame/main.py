from turtle import Screen
from snake import Snake
from food import Food
from Scoreboard import Scoreboard

import time

ALIGNMENT = "center"
FONT = ("Courier", 15, "bold")


screen = Screen()
screen.setup(width=700, height=700)
screen.bgcolor("black")
screen.title("Snake game bulit by Ajay 🐍😁")
screen.tracer(0)
snake = Snake()
food = Food()
score = Scoreboard()

screen.onkey(fun=snake.up, key="Up")
screen.onkeypress(fun=snake.down, key="Down")
screen.onkeypress(fun=snake.left, key="Left")
screen.onkeypress(fun=snake.right, key="Right")
screen.listen()
game_is_on = True
while game_is_on:
    screen.update()
    time.sleep(0.1)
    snake.move()
    # Detect collision with the food.
    if snake.head.distance(food) < 15:
        # refresh the food after detection
        food.refresh()
        # Add another part to the snake
        snake.Extend()
        # Increases the score by 1 each time collision with the food
        score.increase_score()
    # Detect collision with the All four sides of dimensions wall
    if (
        snake.head.xcor() > 350
        or snake.head.xcor() < -350
        or snake.head.ycor() > 350
        or snake.head.ycor() < -350
    ):
        game_is_on = False
        score.game_over()
    # Detect collision tail
    for segment in snake.segments[1:]:
        if snake.head.distance(segment) < 10:
            game_is_on = False
            score.game_over()
screen.exitonclick()
