def life_in_weeks(current_age):
    remaing_age = 90 - current_age
    remaing_weeks = remaing_age * 52
    print(f"You have {remaing_weeks} weeks left.")


life_in_weeks(18)
